#ifndef WIFI_BOARD_H
#define WIFI_BOARD_H

#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/event_groups.h>
#include "board.h"

class WifiBoard : public Board {
protected:
    esp_timer_handle_t connect_timer_ = nullptr;
    bool in_config_mode_ = false;
    NetworkEventCallback network_event_callback_ = nullptr;

    virtual const char* GetWifiSsidPrefix() const { return "Wisio"; }
    virtual bool AppendMacToWifiSsid() const { return true; }
    // ESP-IDF units are 0.25 dBm. Zero keeps the configured/default value.
    // Boards with a tight power budget can cap TX before station/AP startup.
    virtual int8_t GetWifiMaxTxPower() const { return 0; }

    virtual std::string GetBoardJson() override;

    /**
     * Handle network event (called from WiFi manager callbacks)
     * @param event The network event type
     * @param data Additional data (e.g., SSID for Connecting/Connected events)
     */
    void OnNetworkEvent(NetworkEvent event, const std::string& data = "");

    /**
     * Start WiFi connection attempt
     */
    void TryWifiConnect();

    /**
     * Enter WiFi configuration mode
     */
    void StartWifiConfigMode();

    /**
     * WiFi connection timeout callback
     */
    static void OnWifiConnectTimeout(void* arg);

public:
    WifiBoard();
    virtual ~WifiBoard();

    virtual std::string GetBoardType() override;

    /**
     * Start network connection asynchronously
     * This function returns immediately. Network events are notified through the callback set by
     * SetNetworkEventCallback().
     */
    virtual void StartNetwork() override;

    virtual NetworkInterface* GetNetwork() override;
    virtual void SetNetworkEventCallback(NetworkEventCallback callback) override;
    virtual const char* GetNetworkStateIcon() override;
    virtual void SetPowerSaveLevel(PowerSaveLevel level) override;
    virtual AudioCodec* GetAudioCodec() override { return nullptr; }
    virtual std::string GetDeviceStatusJson() override;

    /**
     * Enter WiFi configuration mode (thread-safe, can be called from any task)
     */
    void EnterWifiConfigMode();

    /**
     * Check if in WiFi config mode
     */
    bool IsInWifiConfigMode() const;
};

#endif  // WIFI_BOARD_H
