#include "application.h"
#include <atomic>
#include "assets.h"
#include "assets/lang_config.h"
#include "audio_codec.h"
#include "board.h"
#include "display.h"
#include "display/lvgl_display/lvgl_display.h"
#include "mcp_server.h"
#include "memory_manager.h"
#include "mqtt_protocol.h"
#include "music_message.h"
#include "preview_download.h"
#include "settings.h"
#include "system_info.h"
#include "text_glyph_payload.h"
#include "websocket_protocol.h"

#include <driver/gpio.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <arpa/inet.h>
#include <cJSON.h>
#include <lwip/sockets.h>
#include <mbedtls/base64.h>
#include <cerrno>
#include <algorithm>
#include <cstring>
#include <limits>

#define TAG "Application"

#if CONFIG_BOARD_TYPE_Freenove_ESP32S3_DISPLAY_2_8_LCD
static std::string DiscoverWisioBridge() {
    constexpr uint16_t kDiscoveryPort = 8004;
    constexpr char kRequest[] = "WISIO_DISCOVER_V1";
    constexpr char kResponsePrefix[] = "WISIO_BRIDGE_V1 ";

    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (sock < 0) {
        return {};
    }
    int enabled = 1;
    setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &enabled, sizeof(enabled));
    timeval timeout = {.tv_sec = 0, .tv_usec = 400000};
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    sockaddr_in destination = {};
    destination.sin_family = AF_INET;
    destination.sin_port = htons(kDiscoveryPort);
    destination.sin_addr.s_addr = htonl(INADDR_BROADCAST);

    char response[192] = {};
    int received = -1;
    for (int attempt = 0; attempt < 3; ++attempt) {
        sendto(sock, kRequest, sizeof(kRequest) - 1, 0, reinterpret_cast<sockaddr*>(&destination),
               sizeof(destination));
        received = recvfrom(sock, response, sizeof(response) - 1, 0, nullptr, nullptr);
        if (received > 0) {
            break;
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    close(sock);
    if (received <= 0) {
        return {};
    }
    response[received] = '\0';
    if (strncmp(response, kResponsePrefix, sizeof(kResponsePrefix) - 1) != 0) {
        return {};
    }
    std::string url(response + sizeof(kResponsePrefix) - 1);
    if (url.rfind("http://", 0) != 0 || url.size() > 160) {
        return {};
    }
    return url;
}
#endif

Application::Application() : notify_player_(audio_service_) {
    event_group_ = xEventGroupCreate();

#if CONFIG_USE_DEVICE_AEC && CONFIG_USE_SERVER_AEC
#error "CONFIG_USE_DEVICE_AEC and CONFIG_USE_SERVER_AEC cannot be enabled at the same time"
#elif CONFIG_USE_DEVICE_AEC
    aec_mode_ = kAecOnDeviceSide;
#elif CONFIG_USE_SERVER_AEC
    aec_mode_ = kAecOnServerSide;
#else
    aec_mode_ = kAecOff;
#endif

    esp_timer_create_args_t clock_timer_args = {.callback =
                                                    [](void* arg) {
                                                        Application* app = (Application*)arg;
                                                        xEventGroupSetBits(app->event_group_,
                                                                           MAIN_EVENT_CLOCK_TICK);
                                                    },
                                                .arg = this,
                                                .dispatch_method = ESP_TIMER_TASK,
                                                .name = "clock_timer",
                                                .skip_unhandled_events = true};
    esp_timer_create(&clock_timer_args, &clock_timer_handle_);
}

Application::~Application() {
    notify_player_.Stop();
    if (clock_timer_handle_ != nullptr) {
        esp_timer_stop(clock_timer_handle_);
        esp_timer_delete(clock_timer_handle_);
    }
    vEventGroupDelete(event_group_);
}

bool Application::SetDeviceState(DeviceState state) { return state_machine_.TransitionTo(state); }

void Application::SetChargingMode(bool charging, int battery_level) {
    const bool previous = charging_mode_.exchange(charging);
    if (previous == charging) {
        return;
    }

    // Gate both capture and wake-word paths immediately. The rest runs on the
    // main task so state, protocol, decoder and LVGL updates remain serialized.
    audio_service_.SetSuspended(charging);
    if (charging) {
        audio_service_.EnableVoiceProcessing(false);
        audio_service_.EnableWakeWordDetection(false);
    }
    Schedule([this, charging]() {
        // A fast plug/unplug can supersede a callback before the main task runs.
        if (charging_mode_.load() != charging) {
            return;
        }
        auto& board = Board::GetInstance();
        auto display = board.GetDisplay();
        auto codec = board.GetAudioCodec();
        if (charging) {
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
            }
            if (protocol_ && (GetDeviceState() == kDeviceStateSpeaking ||
                              GetDeviceState() == kDeviceStateListening)) {
                protocol_->SendAbortSpeaking(kAbortReasonNone);
            }
            pending_listening_start_ = false;
            music_playback_ = false;
            music_idle_seconds_ = 0;
            music_playback_token_.clear();
            notify_player_.Stop();
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(false);
            audio_service_.ResetDecoder();
            while (audio_service_.PopPacketFromSendQueue()) {
            }
            codec->EnableInput(false);
            codec->EnableOutput(false);
            if (auto* backlight = board.GetBacklight())
                backlight->SetPowerSaveMode(true);
            display->HideMusicPlayer();
            display->HideChargingScreen();
            display->SetPowerSaveMode(true);
            if (protocol_ && protocol_->IsAudioChannelOpened())
                protocol_->CloseAudioChannel();
            if (GetDeviceState() == kDeviceStateSpeaking ||
                GetDeviceState() == kDeviceStateListening ||
                GetDeviceState() == kDeviceStateConnecting)
                SetDeviceState(kDeviceStateIdle);
            board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
            board.GetLed()->OnStateChanged();
            ESP_LOGI(TAG, "Charging-only mode enabled");
        } else {
            display->HideChargingScreen();
            display->SetPowerSaveMode(false);
            if (auto* backlight = board.GetBacklight())
                backlight->SetPowerSaveMode(false);
            codec->EnableInput(true);
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(true);
            SetDeviceState(kDeviceStateIdle);
            ESP_LOGI(TAG, "Charging-only mode disabled");
        }
    });
}

void Application::Initialize() {
    auto& board = Board::GetInstance();
    SetDeviceState(kDeviceStateStarting);

    // Setup the display
    auto display = board.GetDisplay();
    display->SetupUI();
    // Print board name/version info
    display->SetChatMessage("system", SystemInfo::GetUserAgent().c_str());

    // Setup the audio service
    auto codec = board.GetAudioCodec();
    audio_service_.Initialize(codec);
    audio_service_.Start();

    AudioServiceCallbacks callbacks;
    callbacks.on_send_queue_available = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_SEND_AUDIO);
    };
    callbacks.on_wake_word_detected = [this](const std::string& wake_word) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_WAKE_WORD_DETECTED);
    };
    callbacks.on_vad_change = [this](bool speaking) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_VAD_CHANGE);
    };
    callbacks.on_playback_drained = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_PLAYBACK_DRAINED);
    };
    callbacks.on_playback_progress = [this](uint32_t playback_id, uint32_t media_position_ms) {
        notify_player_.OnPlaybackProgress(playback_id, media_position_ms);
    };
    audio_service_.SetCallbacks(callbacks);

    // Add state change listeners
    state_machine_.AddStateChangeListener([this](DeviceState old_state, DeviceState new_state) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_STATE_CHANGED);
    });

    // Start the clock timer to update the status bar
    esp_timer_start_periodic(clock_timer_handle_, 1000000);

    // Initialize long-term memory manager (SD card 8GB/16GB)
    MemoryManager::GetInstance().Initialize();

    // Add MCP common tools (only once during initialization)
    auto& mcp_server = McpServer::GetInstance();
    mcp_server.AddCommonTools();
    mcp_server.AddUserOnlyTools();

    // Set network event callback for UI updates and network state handling
    board.SetNetworkEventCallback([this](NetworkEvent event, const std::string& data) {
        auto display = Board::GetInstance().GetDisplay();

        switch (event) {
            case NetworkEvent::Scanning:
                display->ShowNotification(Lang::Strings::SCANNING_WIFI, 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::Connecting: {
                if (data.empty()) {
                    // Cellular network - registering without carrier info yet
                    display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                } else {
                    // WiFi or cellular with carrier info
                    std::string msg = Lang::Strings::CONNECT_TO;
                    msg += data;
                    msg += "...";
                    display->ShowNotification(msg.c_str(), 30000);
                }
                break;
            }
            case NetworkEvent::Connected: {
                std::string msg = Lang::Strings::CONNECTED_TO;
                msg += data;
                display->ShowNotification(msg.c_str(), 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_CONNECTED);
                break;
            }
            case NetworkEvent::Disconnected:
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::WifiConfigModeEnter:
                // WiFi config mode enter is handled by WifiBoard internally
                break;
            case NetworkEvent::WifiConfigModeExit:
                // WiFi config mode exit is handled by WifiBoard internally
                break;
            // Cellular modem specific events
            case NetworkEvent::ModemDetecting:
                display->SetStatus(Lang::Strings::DETECTING_MODULE);
                break;
            case NetworkEvent::ModemErrorNoSim:
                Alert(Lang::Strings::ERROR, Lang::Strings::PIN_ERROR, "warning",
                      Lang::Sounds::OGG_ERR_PIN);
                break;
            case NetworkEvent::ModemErrorRegDenied:
                Alert(Lang::Strings::ERROR, Lang::Strings::REG_ERROR, "warning",
                      Lang::Sounds::OGG_ERR_REG);
                break;
            case NetworkEvent::ModemErrorInitFailed:
                Alert(Lang::Strings::ERROR, Lang::Strings::MODEM_INIT_ERROR, "warning",
                      Lang::Sounds::OGG_EXCLAMATION);
                break;
            case NetworkEvent::ModemErrorTimeout:
                display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                break;
        }
    });

    // Start network asynchronously
    board.StartNetwork();

    // Update the status bar immediately to show the network state
    display->UpdateStatusBar(true);
}

void Application::Run() {
    // Set the priority of the main task to 10
    vTaskPrioritySet(nullptr, 10);

    const EventBits_t ALL_EVENTS =
        MAIN_EVENT_SCHEDULE | MAIN_EVENT_SEND_AUDIO | MAIN_EVENT_WAKE_WORD_DETECTED |
        MAIN_EVENT_VAD_CHANGE | MAIN_EVENT_CLOCK_TICK | MAIN_EVENT_ERROR |
        MAIN_EVENT_NETWORK_CONNECTED | MAIN_EVENT_NETWORK_DISCONNECTED | MAIN_EVENT_TOGGLE_CHAT |
        MAIN_EVENT_START_LISTENING | MAIN_EVENT_STOP_LISTENING | MAIN_EVENT_ACTIVATION_DONE |
        MAIN_EVENT_STATE_CHANGED | MAIN_EVENT_PLAYBACK_DRAINED;

    while (true) {
        auto bits = xEventGroupWaitBits(event_group_, ALL_EVENTS, pdTRUE, pdFALSE, portMAX_DELAY);

        if (bits & MAIN_EVENT_ERROR) {
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
            }
            SetDeviceState(kDeviceStateIdle);
            Alert(Lang::Strings::ERROR, last_error_message_.c_str(), "cancel",
                  Lang::Sounds::OGG_EXCLAMATION);
        }

        if (bits & MAIN_EVENT_NETWORK_CONNECTED) {
            HandleNetworkConnectedEvent();
        }

        if (bits & MAIN_EVENT_NETWORK_DISCONNECTED) {
            HandleNetworkDisconnectedEvent();
        }

        if (bits & MAIN_EVENT_ACTIVATION_DONE) {
            HandleActivationDoneEvent();
        }

        if (bits & MAIN_EVENT_STATE_CHANGED) {
            HandleStateChangedEvent();
        }

        if (bits & MAIN_EVENT_PLAYBACK_DRAINED) {
            if (audio_service_.IsPlaybackIdle()) {
                notify_player_.OnPlaybackDrained();
            }
            // Deferred listening start (auto mode): the playback queue has
            // drained, so it is now safe to enable voice processing.
            if (pending_listening_start_ && GetDeviceState() == kDeviceStateListening &&
                audio_service_.IsPlaybackIdle()) {
                pending_listening_start_ = false;
                StartListeningAudio();
            }
        }

        if (bits & MAIN_EVENT_TOGGLE_CHAT) {
            HandleToggleChatEvent();
        }

        if (bits & MAIN_EVENT_START_LISTENING) {
            HandleStartListeningEvent();
        }

        if (bits & MAIN_EVENT_STOP_LISTENING) {
            HandleStopListeningEvent();
        }

        if (bits & MAIN_EVENT_SEND_AUDIO) {
            while (auto packet = audio_service_.PopPacketFromSendQueue()) {
                if (charging_mode_.load()) {
                    continue;
                }
                if (protocol_ && !protocol_->SendAudio(std::move(packet))) {
                    // Drop the remaining packets. Leaving them in the queue would
                    // stall the Opus codec task (it waits for queue space), which in
                    // turn deadlocks the whole audio input pipeline, as no new
                    // MAIN_EVENT_SEND_AUDIO event would ever be triggered again.
                    while (audio_service_.PopPacketFromSendQueue())
                        ;
                    break;
                }
            }
        }

        if (bits & MAIN_EVENT_WAKE_WORD_DETECTED) {
            HandleWakeWordDetectedEvent();
        }

        if (bits & MAIN_EVENT_VAD_CHANGE) {
            if (GetDeviceState() == kDeviceStateListening) {
                auto led = Board::GetInstance().GetLed();
                led->OnStateChanged();
            }
        }

        if (bits & MAIN_EVENT_SCHEDULE) {
            std::unique_lock<std::mutex> lock(mutex_);
            auto tasks = std::move(main_tasks_);
            lock.unlock();
            for (auto& task : tasks) {
                task();
            }
        }

        if (bits & MAIN_EVENT_CLOCK_TICK) {
            if (charging_mode_.load()) continue;
            clock_ticks_++;
            auto display = Board::GetInstance().GetDisplay();
            display->UpdateStatusBar();

            if (music_playback_) {
                if (audio_service_.IsPlaybackIdle()) {
                    music_idle_seconds_++;
                    if (music_idle_seconds_ >= 4) {
                        ESP_LOGI(TAG, "Music playback idle timeout, returning to idle");
                        music_playback_ = false;
                        music_playback_token_.clear();
                        display->HideMusicPlayer();
                        music_idle_seconds_ = 0;
                        if (GetDeviceState() == kDeviceStateSpeaking) {
                            SetDeviceState(kDeviceStateIdle);
                        }
                    }
                } else {
                    music_idle_seconds_ = 0;
                }
            } else {
                music_idle_seconds_ = 0;
            }

            // Print debug info every 10 seconds
            if (clock_ticks_ % 10 == 0) {
                SystemInfo::PrintHeapStats();
                // SystemInfo::PrintTaskList();
                // SystemInfo::PrintTaskCpuUsage(pdMS_TO_TICKS(1000));
            }
        }
    }
}

void Application::HandleNetworkConnectedEvent() {
    ESP_LOGI(TAG, "Network connected");
    auto state = GetDeviceState();

    if (state == kDeviceStateStarting || state == kDeviceStateWifiConfiguring) {
        // Network is ready, start activation
        SetDeviceState(kDeviceStateActivating);
        if (activation_task_handle_ != nullptr) {
            ESP_LOGW(TAG, "Activation task already running");
            return;
        }

        xTaskCreate(
            [](void* arg) {
                Application* app = static_cast<Application*>(arg);
                app->ActivationTask();
                app->activation_task_handle_ = nullptr;
                vTaskDelete(NULL);
            },
            "activation", 4096 * 2, this, 2, &activation_task_handle_);
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleNetworkDisconnectedEvent() {
    // Close current conversation when network disconnected
    auto state = GetDeviceState();
    if (state == kDeviceStateNotifying) {
        StopNotification();
    }
    if (state == kDeviceStateConnecting || state == kDeviceStateListening ||
        state == kDeviceStateSpeaking) {
        ESP_LOGI(TAG, "Closing audio channel due to network disconnection");
        protocol_->CloseAudioChannel();
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleActivationDoneEvent() {
    ESP_LOGI(TAG, "Activation done");

    SystemInfo::PrintHeapStats();
    SetDeviceState(kDeviceStateIdle);

    has_server_time_ = ota_->HasServerTime();

    auto display = Board::GetInstance().GetDisplay();
    std::string message = std::string(Lang::Strings::VERSION) + ota_->GetCurrentVersion();
    display->ShowNotification(message.c_str());
    display->SetChatMessage("system", "");

    // Release OTA object after activation is complete
    ota_.reset();
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);

#if CONFIG_BOARD_TYPE_Freenove_ESP32S3_DISPLAY_2_8_LCD
    // Keep the ready chime behind the custom loading screen. This task waits
    // without blocking the application event loop, allowing the LVGL timer to
    // finish the progress bar and slide transition first.
    if (xTaskCreate(
            [](void* arg) {
                auto* app = static_cast<Application*>(arg);
                auto display = Board::GetInstance().GetDisplay();
                while (!display->IsStartupComplete()) {
                    vTaskDelay(pdMS_TO_TICKS(100));
                }
                vTaskDelay(pdMS_TO_TICKS(150));
                app->Schedule([app]() {
                    if (!app->IsChargingMode()) app->PlaySound(Lang::Sounds::OGG_SUCCESS);
                });
                // Open the first conversation after the ready chime so the
                // server can introduce Wisio without waiting for a button.
                vTaskDelay(pdMS_TO_TICKS(900));
                app->Schedule([app]() {
                    if (!app->IsChargingMode() &&
                        app->GetDeviceState() == kDeviceStateIdle) {
                        app->ToggleChatState();
                    }
                });
                vTaskDelete(nullptr);
            },
            "ready_chime", 2048, this, 2, nullptr) != pdPASS) {
        Schedule([this]() { PlaySound(Lang::Sounds::OGG_SUCCESS); });
    }
#else
    Schedule([this]() { PlaySound(Lang::Sounds::OGG_SUCCESS); });
#endif
}

void Application::ActivationTask() {
    // Create OTA object for activation process
    ota_ = std::make_unique<Ota>();

    // Check for new assets version
    CheckAssetsVersion();

    // Check for new firmware version
    CheckNewVersion();

    // Initialize the protocol
    InitializeProtocol();

    // Signal completion to main loop
    xEventGroupSetBits(event_group_, MAIN_EVENT_ACTIVATION_DONE);
}

void Application::CheckAssetsVersion() {
    // Only allow CheckAssetsVersion to be called once
    if (assets_version_checked_) {
        return;
    }
    assets_version_checked_ = true;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto& assets = Assets::GetInstance();

    if (!assets.partition_valid()) {
        ESP_LOGW(TAG, "Assets partition is disabled for board %s", BOARD_NAME);
        return;
    }

    Settings settings("assets", true);
    // Check if there is a new assets need to be downloaded
    std::string download_url = settings.GetString("download_url");

    if (!download_url.empty()) {
        settings.EraseKey("download_url");

        char message[256];
        snprintf(message, sizeof(message), Lang::Strings::FOUND_NEW_ASSETS, download_url.c_str());
        Alert(Lang::Strings::LOADING_ASSETS, message, "cloud_download", Lang::Sounds::OGG_UPGRADE);

        // Wait for the audio service to be idle for 3 seconds
        vTaskDelay(pdMS_TO_TICKS(3000));
        SetDeviceState(kDeviceStateUpgrading);
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        display->SetChatMessage("system", Lang::Strings::PLEASE_WAIT);

        bool success =
            assets.Download(download_url, [this, display](int progress, size_t speed) -> void {
                char buffer[32];
                snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
                Schedule([display, message = std::string(buffer)]() {
                    display->SetChatMessage("system", message.c_str());
                });
            });

        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        vTaskDelay(pdMS_TO_TICKS(1000));

        if (!success) {
            Alert(Lang::Strings::ERROR, Lang::Strings::DOWNLOAD_ASSETS_FAILED, "cancel",
                  Lang::Sounds::OGG_EXCLAMATION);
            vTaskDelay(pdMS_TO_TICKS(2000));
            SetDeviceState(kDeviceStateActivating);
            return;
        }
    }

    // Apply assets
    assets.Apply();
    display->SetChatMessage("system", "");
    display->SetEmotion("robot_2");
}

void Application::CheckNewVersion() {
    const int MAX_RETRY = 2;
    int retry_count = 0;
    const int retry_delay = 1;

    auto& board = Board::GetInstance();
    while (true) {
        const int64_t check_started_us = esp_timer_get_time();
        auto display = board.GetDisplay();
        display->SetStatus(Lang::Strings::CHECKING_NEW_VERSION);

        std::string configured_url = ota_->GetCheckVersionUrl();
#if CONFIG_BOARD_TYPE_Freenove_ESP32S3_DISPLAY_2_8_LCD
        // The setup portal intentionally has no technical/advanced tab. Find
        // the Windows bridge on the same LAN so every family can use the same
        // firmware without typing a PC address.
        const std::string discovered_url = DiscoverWisioBridge();
        if (!discovered_url.empty() && discovered_url != configured_url) {
            ESP_LOGI(TAG, "Discovered Wisio bridge at %s", discovered_url.c_str());
            Settings settings("wifi", true);
            settings.SetString("ota_url", discovered_url);
            configured_url = discovered_url;
        }
#endif
        std::string attempted_url = configured_url;
        esp_err_t err = ota_->CheckVersion(configured_url);
        ESP_LOGI(TAG, "OTA check finished in %lld ms, result=%d",
                 (long long)((esp_timer_get_time() - check_started_us) / 1000), err);
        const bool connection_failed =
            err == EHOSTUNREACH || err == ENETUNREACH || err == ETIMEDOUT || err == ECONNREFUSED;
#if CONFIG_BOARD_TYPE_Freenove_ESP32S3_DISPLAY_2_8_LCD
        // This board is provisioned for a per-user PC bridge. Never replace a
        // temporarily unreachable user URL with the developer build default.
        const bool allow_builtin_ota_fallback = false;
#else
        const bool allow_builtin_ota_fallback = true;
#endif
        if (connection_failed && configured_url != CONFIG_OTA_URL && allow_builtin_ota_fallback) {
            ESP_LOGW(TAG, "OTA URL %s failed (code=%d); trying built-in URL %s",
                     configured_url.c_str(), err, CONFIG_OTA_URL);
            attempted_url = CONFIG_OTA_URL;
            esp_err_t fallback_err = ota_->CheckVersion(CONFIG_OTA_URL);
            if (fallback_err == ESP_OK) {
                ESP_LOGI(TAG, "Built-in OTA URL works; replacing the unreachable saved URL");
                Settings settings("wifi", true);
                settings.SetString("ota_url", CONFIG_OTA_URL);
                err = ESP_OK;
            } else {
                err = fallback_err;
            }
        }
        if (err != ESP_OK) {
            retry_count++;
            if (retry_count >= MAX_RETRY) {
                ESP_LOGE(TAG, "OTA server unreachable after %d attempts: code=%d, url=%s",
                         retry_count, err, attempted_url.c_str());
                display->ShowNotification("Không tới được server. Kiểm tra máy tính và Wi-Fi.",
                                          5000);
                return;
            }

            char error_message[128];
            int error_message_length = snprintf(error_message, sizeof(error_message),
                                                "code=%d, url=%s", err, attempted_url.c_str());
            if (error_message_length < 0 ||
                error_message_length >= static_cast<int>(sizeof(error_message))) {
                snprintf(error_message, sizeof(error_message), "code=%d", err);
            }

            ESP_LOGW(TAG, "Check new version failed, retry in %d seconds (%d/%d)", retry_delay,
                     retry_count, MAX_RETRY);
            ESP_LOGW(TAG, "OTA failure detail: %s", error_message);
            for (int i = 0; i < retry_delay; i++) {
                vTaskDelay(pdMS_TO_TICKS(1000));
                if (GetDeviceState() == kDeviceStateIdle) {
                    break;
                }
            }
            continue;
        }
        retry_count = 0;

        if (ota_->HasNewVersion()) {
            if (UpgradeFirmware(ota_->GetFirmwareUrl(), ota_->GetFirmwareVersion())) {
                return;  // This line will never be reached after reboot
            }
            // If upgrade failed, continue to normal operation
        }

        // No new version, mark the current version as valid
        ota_->MarkCurrentVersionValid();
        if (!ota_->HasActivationCode() && !ota_->HasActivationChallenge()) {
            // Exit the loop if done checking new version
            break;
        }

        display->SetStatus(Lang::Strings::ACTIVATION);
        // Activation code is shown to the user and waiting for the user to input
        if (ota_->HasActivationCode()) {
            ShowActivationCode(ota_->GetActivationCode(), ota_->GetActivationMessage());
        }

        // This will block the loop until the activation is done or timeout
        for (int i = 0; i < 10; ++i) {
            ESP_LOGI(TAG, "Activating... %d/%d", i + 1, 10);
            esp_err_t err = ota_->Activate();
            if (err == ESP_OK) {
                break;
            } else if (err == ESP_ERR_TIMEOUT) {
                vTaskDelay(pdMS_TO_TICKS(3000));
            } else {
                vTaskDelay(pdMS_TO_TICKS(10000));
            }
            if (GetDeviceState() == kDeviceStateIdle) {
                break;
            }
        }
    }
}

void Application::InitializeProtocol() {
    const int64_t protocol_started_us = esp_timer_get_time();
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto codec = board.GetAudioCodec();

    display->SetStatus(Lang::Strings::LOADING_PROTOCOL);

// This Freenove build uses the PC bridge. An old MQTT configuration in flash
// must never silently reconnect it to the public Wisio service.
#if CONFIG_BOARD_TYPE_Freenove_ESP32S3_DISPLAY_2_8_LCD
    protocol_ = std::make_unique<WebsocketProtocol>();
#else
    if (ota_->HasMqttConfig()) {
        protocol_ = std::make_unique<MqttProtocol>();
    } else if (ota_->HasWebsocketConfig()) {
        protocol_ = std::make_unique<WebsocketProtocol>();
    } else {
        ESP_LOGW(TAG, "No protocol specified in the OTA config, using MQTT");
        protocol_ = std::make_unique<MqttProtocol>();
    }
#endif
    ESP_LOGI(TAG, "Protocol selected in %lld ms",
             (long long)((esp_timer_get_time() - protocol_started_us) / 1000));

    protocol_->OnConnected([this]() { DismissAlert(); });

    protocol_->OnNetworkError([this](const std::string& message) {
        last_error_message_ = message;
        xEventGroupSetBits(event_group_, MAIN_EVENT_ERROR);
    });

    protocol_->OnIncomingAudio([this](std::unique_ptr<AudioStreamPacket> packet) {
        if (charging_mode_.load()) {
            return;
        }
        if (GetDeviceState() == kDeviceStateSpeaking) {
            if (!audio_service_.PushPacketToDecodeQueue(std::move(packet))) {
                static int64_t last_decode_drop_log_us = 0;
                const int64_t now_us = esp_timer_get_time();
                if (now_us - last_decode_drop_log_us >= 1000000) {
                    last_decode_drop_log_us = now_us;
                    ESP_LOGW(TAG, "Playback queue full; incoming audio packet dropped");
                }
            }
        }
    });

    protocol_->OnAudioChannelOpened([this, codec, &board]() {
        if (charging_mode_.load()) {
            Schedule([this]() {
                if (charging_mode_.load() && protocol_ && protocol_->IsAudioChannelOpened()) {
                    protocol_->CloseAudioChannel();
                }
            });
            return;
        }
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        if (protocol_->server_sample_rate() != codec->output_sample_rate()) {
            ESP_LOGW(TAG,
                     "Server sample rate %d does not match device output sample rate %d, "
                     "resampling may cause distortion",
                     protocol_->server_sample_rate(), codec->output_sample_rate());
        }
    });

    protocol_->OnAudioChannelClosed([this, &board]() {
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        Schedule([this]() {
            auto display = Board::GetInstance().GetDisplay();
            display->SetChatMessage("system", "");
            SetDeviceState(kDeviceStateIdle);
        });
    });

    protocol_->OnIncomingJson([this, display](const cJSON* root) {
        // Parse JSON data
        auto type = cJSON_GetObjectItem(root, "type");
        if (!cJSON_IsString(type)) {
            ESP_LOGW(TAG, "Incoming JSON message has no type");
            return;
        }
        if (charging_mode_.load()) {
            ESP_LOGD(TAG, "Ignored %s while charging", type->valuestring);
            return;
        }
        if (strcmp(type->valuestring, "notify") == 0) {
            auto audio_url = cJSON_GetObjectItem(root, "audio_url");
            if (!cJSON_IsString(audio_url) || audio_url->valuestring[0] == '\0') {
                ESP_LOGW(TAG, "Notify message requires audio_url");
                return;
            }

            std::vector<NotifySubtitle> subtitles;
            auto subtitles_json = cJSON_GetObjectItem(root, "subtitles");
            if (subtitles_json != nullptr && !cJSON_IsArray(subtitles_json)) {
                ESP_LOGW(TAG, "Notify subtitles must be an array");
                return;
            }
            if (cJSON_IsArray(subtitles_json)) {
                cJSON* item = nullptr;
                cJSON_ArrayForEach (item, subtitles_json) {
                    auto start_ms = cJSON_GetObjectItem(item, "start_ms");
                    auto text = cJSON_GetObjectItem(item, "text");
                    if (!cJSON_IsNumber(start_ms) || start_ms->valuedouble < 0 ||
                        start_ms->valuedouble > std::numeric_limits<uint32_t>::max() ||
                        !cJSON_IsString(text)) {
                        ESP_LOGW(TAG, "Ignoring invalid notify subtitle");
                        continue;
                    }
                    subtitles.push_back({.start_ms = static_cast<uint32_t>(start_ms->valuedouble),
                                         .text = text->valuestring});
                }
            }

            Schedule([this, url = std::string(audio_url->valuestring),
                      subtitles = std::move(subtitles)]() mutable {
                StartNotification(std::move(url), std::move(subtitles));
            });
        } else if (strcmp(type->valuestring, "volume") == 0) {
            auto action_json = cJSON_GetObjectItem(root, "action");
            if (!cJSON_IsString(action_json)) {
                return;
            }
            const std::string action(action_json->valuestring);
            auto value_json = cJSON_GetObjectItem(root, "value");
            auto step_json = cJSON_GetObjectItem(root, "step");
            const int value = cJSON_IsNumber(value_json) ? value_json->valueint : 70;
            const int step = cJSON_IsNumber(step_json) ? step_json->valueint : 10;
            Schedule([display, action, value, step]() {
                auto* codec = Board::GetInstance().GetAudioCodec();
                int volume = codec->output_volume();
                if (action == "up")
                    volume += step;
                else if (action == "down")
                    volume -= step;
                else if (action == "mute")
                    volume = 0;
                else if (action == "set")
                    volume = value;
                else
                    return;
                volume = std::max(0, std::min(100, volume));
                codec->SetOutputVolume(volume);
                display->ShowNotification("Âm lượng " + std::to_string(volume) + "%");
            });
        } else if (strcmp(type->valuestring, "music") == 0) {
            auto state = cJSON_GetObjectItem(root, "state");
            if (!cJSON_IsString(state)) {
                return;
            }
            auto token_json = cJSON_GetObjectItem(root, "playback_token");
            std::string token;
            if (cJSON_IsString(token_json) && strlen(token_json->valuestring) <= 64) {
                token = token_json->valuestring;
            }
            const auto music_state = ParseMusicMessageState(state->valuestring);
            struct MusicCover {
                std::unique_ptr<void, decltype(&heap_caps_free)> data{nullptr, heap_caps_free};
                size_t size = 0;
                uint32_t accent = 0x38BDF8;
            };
            auto ReadMusicCover = [root, display]() {
                auto cover = std::make_shared<MusicCover>();
                auto accent = cJSON_GetObjectItem(root, "accent_color");
                if (cJSON_IsNumber(accent) && accent->valuedouble >= 0 &&
                    accent->valuedouble <= 0xFFFFFF) {
                    cover->accent = static_cast<uint32_t>(accent->valuedouble);
                } else if (cJSON_IsString(accent)) {
                    const char* text = accent->valuestring;
                    if (*text == '#')
                        ++text;
                    else if (text[0] == '0' && (text[1] == 'x' || text[1] == 'X'))
                        text += 2;
                    char* end = nullptr;
                    const auto color = strtoul(text, &end, 16);
                    if (strlen(text) == 6 && end == text + 6 && color <= 0xFFFFFF)
                        cover->accent = static_cast<uint32_t>(color);
                }
#if HAVE_LVGL
                if (dynamic_cast<LvglDisplay*>(display) == nullptr)
                    return cover;
#else
                return cover;
#endif
                auto encoded = cJSON_GetObjectItem(root, "data");
                if (!cJSON_IsString(encoded))
                    return cover;
                const size_t encoded_size = strlen(encoded->valuestring);
                constexpr size_t kMaxEncodedCoverSize = 320 * 1024;
                constexpr size_t kMaxDecodedCoverSize = 240 * 1024;
                const size_t allocation_size = (encoded_size / 4) * 3 + 3;
                if (encoded_size == 0 || encoded_size > kMaxEncodedCoverSize ||
                    allocation_size > kMaxDecodedCoverSize) {
                    ESP_LOGW(TAG, "Rejected oversized music cover");
                    return cover;
                }
                cover->data.reset(heap_caps_malloc(allocation_size, MALLOC_CAP_8BIT));
                if (!cover->data) {
                    ESP_LOGW(TAG, "Not enough memory for music cover; using music artwork");
                    return cover;
                }
                const int result = mbedtls_base64_decode(
                    static_cast<unsigned char*>(cover->data.get()), allocation_size, &cover->size,
                    reinterpret_cast<const unsigned char*>(encoded->valuestring), encoded_size);
                if (result != 0 ||
                    !IsMusicCoverPng(static_cast<const uint8_t*>(cover->data.get()), cover->size)) {
                    ESP_LOGW(TAG, "Rejected invalid music cover; using music artwork");
                    cover->data.reset();
                    cover->size = 0;
                }
                return cover;
            };
            if (music_state == MusicMessageState::kStart) {
                auto title_json = cJSON_GetObjectItem(root, "title");
                auto artist_json = cJSON_GetObjectItem(root, "artist");
                auto duration_json = cJSON_GetObjectItem(root, "duration_ms");
                auto position_json = cJSON_GetObjectItem(root, "position_ms");
                std::string title =
                    cJSON_IsString(title_json) && strlen(title_json->valuestring) <= 160
                        ? title_json->valuestring
                        : "";
                std::string artist =
                    cJSON_IsString(artist_json) && strlen(artist_json->valuestring) <= 160
                        ? artist_json->valuestring
                        : "";
                uint32_t duration_ms = 0;
                if (cJSON_IsNumber(duration_json) && duration_json->valuedouble >= 0 &&
                    duration_json->valuedouble <= std::numeric_limits<uint32_t>::max()) {
                    duration_ms = static_cast<uint32_t>(duration_json->valuedouble);
                }
                const bool has_position =
                    cJSON_IsNumber(position_json) && position_json->valuedouble >= 0 &&
                    position_json->valuedouble <= std::numeric_limits<uint32_t>::max();
                const uint32_t position_ms =
                    has_position
                        ? ClampMusicPosition(static_cast<uint32_t>(position_json->valuedouble),
                                             duration_ms)
                        : 0;
                auto cover = ReadMusicCover();
                Schedule([this, display, token = std::move(token), title = std::move(title),
                          artist = std::move(artist), duration_ms, has_position, position_ms,
                          cover]() {
                    const bool same_playback =
                        music_playback_ && !token.empty() && music_playback_token_ == token;
                    music_playback_ = true;
                    aborted_ = false;
                    music_idle_seconds_ = 0;
                    if (same_playback) {
                        // A late listen event reasserts the existing player;
                        // keep its cover and never reset elapsed time to zero.
                        if (has_position) {
                            display->UpdateMusicProgress(position_ms, duration_ms);
                        }
                    } else if (!token.empty()) {
                        music_playback_token_ = token;
#if HAVE_LVGL
                        if (auto* lvgl_display = dynamic_cast<LvglDisplay*>(display)) {
                            DisplayLockGuard lock(lvgl_display);
                            std::unique_ptr<LvglImage> image;
                            if (cover->data) {
                                try {
                                    image = std::make_unique<LvglAllocatedImage>(cover->data.get(),
                                                                                 cover->size);
                                    cover->data.release();
                                } catch (const std::exception& error) {
                                    ESP_LOGW(TAG, "Cannot decode music cover: %s", error.what());
                                }
                            }
                            lvgl_display->ShowMusicPlayerWithCover(title, artist, duration_ms,
                                                                   std::move(image), cover->accent);
                        } else
#endif
                            display->ShowMusicPlayer(title, artist, duration_ms);
                    }
                    SetDeviceState(kDeviceStateSpeaking);
                    // Music must only be interrupted by a physical button or touch.
                    audio_service_.EnableVoiceProcessing(false);
                    audio_service_.EnableWakeWordDetection(false);
                });
            } else if (music_state == MusicMessageState::kCover) {
                if (token.empty()) {
                    ESP_LOGW(TAG, "Music cover requires a token");
                    return;
                }
                auto cover = ReadMusicCover();
                if (!cover->data)
                    return;
                Schedule([this, display, token = std::move(token), cover]() {
                    if (!music_playback_ || music_playback_token_ != token) {
                        return;
                    }
#if HAVE_LVGL
                    auto* lvgl_display = dynamic_cast<LvglDisplay*>(display);
                    if (lvgl_display == nullptr) {
                        return;
                    }
                    DisplayLockGuard lock(lvgl_display);
                    try {
                        auto image =
                            std::make_unique<LvglAllocatedImage>(cover->data.get(), cover->size);
                        cover->data.release();
                        lvgl_display->SetMusicCover(std::move(image));
                        lvgl_display->SetMusicAccentColor(cover->accent);
                    } catch (const std::exception& error) {
                        ESP_LOGE(TAG, "Cannot display music cover: %s", error.what());
                    }
#endif
                });
            } else if (music_state == MusicMessageState::kProgress) {
                auto position_json = cJSON_GetObjectItem(root, "position_ms");
                auto duration_json = cJSON_GetObjectItem(root, "duration_ms");
                if (token.empty() || !cJSON_IsNumber(position_json) ||
                    !cJSON_IsNumber(duration_json) || position_json->valuedouble < 0 ||
                    duration_json->valuedouble < 0 ||
                    position_json->valuedouble > std::numeric_limits<uint32_t>::max() ||
                    duration_json->valuedouble > std::numeric_limits<uint32_t>::max()) {
                    ESP_LOGW(TAG, "Rejected invalid music progress");
                    return;
                }
                uint32_t position_ms = static_cast<uint32_t>(position_json->valuedouble);
                const uint32_t duration_ms = static_cast<uint32_t>(duration_json->valuedouble);
                if (duration_ms > 0 && position_ms > duration_ms) {
                    position_ms = duration_ms;
                }
                Schedule([this, display, token = std::move(token), position_ms, duration_ms]() {
                    if (music_playback_token_ != token) {
                        return;
                    }
                    display->UpdateMusicProgress(position_ms, duration_ms);
                });
            } else if (music_state == MusicMessageState::kStop) {
                Schedule([this, display, token = std::move(token)]() {
                    if (!token.empty() && !music_playback_token_.empty() &&
                        music_playback_token_ != token) {
                        return;
                    }
                    music_playback_ = false;
                    music_playback_token_.clear();
                    display->HideMusicPlayer();
                    if (GetDeviceState() == kDeviceStateSpeaking) {
                        if (listening_mode_ == kListeningModeManualStop) {
                            SetDeviceState(kDeviceStateIdle);
                        } else {
                            SetDeviceState(kDeviceStateListening);
                        }
                    }
                });
            } else {
                ESP_LOGW(TAG, "Unknown music state: %s", state->valuestring);
            }
        } else if (strcmp(type->valuestring, "learning_image") == 0) {
            auto encoded = cJSON_GetObjectItem(root, "data");
            auto url = cJSON_GetObjectItem(root, "url");

            if (cJSON_IsString(url) &&
                (!cJSON_IsString(encoded) || strlen(encoded->valuestring) == 0)) {
#if HAVE_LVGL
                static std::atomic<bool> image_loading{false};
                if (image_loading.exchange(true)) {
                    ESP_LOGW(TAG, "Ignoring overlapping learning image download");
                    return;
                }
                auto* request = new (std::nothrow) std::string(url->valuestring);
                if (!request ||
                    xTaskCreate(
                        [](void* arg) {
                            std::unique_ptr<std::string> image_url(static_cast<std::string*>(arg));
                            try {
                                auto http = Board::GetInstance().GetNetwork()->CreateHttp(3);
                                if (!http) {
                                    throw std::runtime_error("Image HTTP transport is unavailable");
                                }
                                auto bytes = DownloadPreviewImage(*http, *image_url);
                                Application::GetInstance().Schedule([bytes = std::move(bytes)]() {
                                    try {
                                        auto* screen = dynamic_cast<LvglDisplay*>(
                                            Board::GetInstance().GetDisplay());
                                        if (!screen) {
                                            throw std::runtime_error(
                                                "Display does not support images");
                                        }
                                        std::unique_ptr<void, decltype(&heap_caps_free)> data(
                                            heap_caps_malloc(bytes.size(), MALLOC_CAP_8BIT),
                                            heap_caps_free);
                                        if (!data) {
                                            throw std::runtime_error("Not enough memory for image");
                                        }
                                        memcpy(data.get(), bytes.data(), bytes.size());
                                        DisplayLockGuard lock(screen);
                                        auto image = std::make_unique<LvglAllocatedImage>(
                                            data.get(), bytes.size());
                                        data.release();
                                        screen->SetPreviewImage(std::move(image));
                                    } catch (const std::exception& error) {
                                        ESP_LOGE(TAG, "Cannot display learning image: %s",
                                                 error.what());
                                    }
                                    image_loading.store(false);
                                });
                            } catch (const std::exception& error) {
                                ESP_LOGE(TAG, "Cannot download learning image: %s", error.what());
                                image_loading.store(false);
                            }
                            image_url.reset();  // vTaskDelete does not unwind C++ stack objects.
                            vTaskDelete(nullptr);
                        },
                        "dl_image", 6144, request, 2, nullptr) != pdPASS) {
                    delete request;
                    image_loading.store(false);
                    ESP_LOGE(TAG, "Cannot start learning image download");
                }
#else
                ESP_LOGW(TAG, "Learning images require an LVGL display");
#endif
                return;
            }

            if (!cJSON_IsString(encoded)) {
                ESP_LOGW(TAG, "Learning image requires base64 data or url");
                return;
            }
            const size_t encoded_size = strlen(encoded->valuestring);
            constexpr size_t kMaxEncodedImageSize = 320 * 1024;
            constexpr size_t kMaxDecodedImageSize = 240 * 1024;
            if (encoded_size == 0 || encoded_size > kMaxEncodedImageSize) {
                ESP_LOGW(TAG, "Rejected oversized learning image: %u bytes",
                         static_cast<unsigned>(encoded_size));
                return;
            }
            const size_t allocation_size = (encoded_size / 4) * 3 + 3;
            if (allocation_size > kMaxDecodedImageSize) {
                ESP_LOGW(TAG, "Rejected learning image requiring %u bytes",
                         static_cast<unsigned>(allocation_size));
                return;
            }
            auto* image_data =
                static_cast<uint8_t*>(heap_caps_malloc(allocation_size, MALLOC_CAP_8BIT));
            if (image_data == nullptr) {
                ESP_LOGE(TAG, "Not enough memory for learning image");
                return;
            }
            size_t decoded_size = 0;
            int result = mbedtls_base64_decode(
                image_data, allocation_size, &decoded_size,
                reinterpret_cast<const unsigned char*>(encoded->valuestring), encoded_size);
            constexpr uint8_t kPngSignature[] = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1a, '\n'};
            bool is_png = decoded_size >= sizeof(kPngSignature) &&
                          memcmp(image_data, kPngSignature, sizeof(kPngSignature)) == 0;
            bool is_jpeg = decoded_size >= 3 && image_data[0] == 0xFF && image_data[1] == 0xD8 &&
                           image_data[2] == 0xFF;
            if (result != 0 || (!is_png && !is_jpeg)) {
                ESP_LOGW(TAG, "Rejected invalid learning image format (decode result %d)", result);
                heap_caps_free(image_data);
                return;
            }
            Schedule([display, image_data, decoded_size]() {
#if HAVE_LVGL
                std::unique_ptr<void, decltype(&heap_caps_free)> data(image_data, heap_caps_free);
                try {
                    auto* lvgl_display = dynamic_cast<LvglDisplay*>(display);
                    if (lvgl_display == nullptr) {
                        ESP_LOGW(TAG, "This display does not support learning images");
                        return;
                    }
                    DisplayLockGuard lock(lvgl_display);
                    auto image = std::make_unique<LvglAllocatedImage>(data.get(), decoded_size);
                    data.release();
                    lvgl_display->SetPreviewImage(std::move(image));
                } catch (const std::exception& error) {
                    ESP_LOGE(TAG, "Cannot display learning image: %s", error.what());
                }
#else
                ESP_LOGW(TAG, "Learning images require an LVGL display");
                heap_caps_free(image_data);
#endif
            });
        } else if (strcmp(type->valuestring, "listen") == 0) {
            // The local Gemini bridge sends listen:stop as soon as the user's
            // utterance is complete. Reflect the processing interval on the
            // status dot and disable the microphone until a reply is ready.
            auto state = cJSON_GetObjectItem(root, "state");
            if (!cJSON_IsString(state)) {
                return;
            }
            if (strcmp(state->valuestring, "stop") == 0) {
                Schedule([this]() {
                    if (GetDeviceState() == kDeviceStateListening) {
                        SetDeviceState(kDeviceStateIdle);
                    }
                });
            } else if (strcmp(state->valuestring, "start") == 0) {
                Schedule([this]() {
                    if (GetDeviceState() == kDeviceStateIdle ||
                        GetDeviceState() == kDeviceStateConnecting) {
                        SetDeviceState(kDeviceStateListening);
                    }
                });
            }
        } else if (strcmp(type->valuestring, "tts") == 0) {
            auto state = cJSON_GetObjectItem(root, "state");
            if (!cJSON_IsString(state)) {
                return;
            }
            if (strcmp(state->valuestring, "start") == 0) {
                Schedule([this]() {
                    aborted_ = false;
                    SetDeviceState(kDeviceStateSpeaking);
                });
            } else if (strcmp(state->valuestring, "stop") == 0) {
                Schedule([this]() {
                    if (GetDeviceState() == kDeviceStateSpeaking) {
                        // A play request may already be searching or waiting for
                        // its post-speech delay. Keep the UI yellow and the mic
                        // locked until the bridge sends music:stop.
                        if (music_playback_) {
                            audio_service_.EnableVoiceProcessing(false);
                            audio_service_.EnableWakeWordDetection(false);
                        } else if (listening_mode_ == kListeningModeManualStop) {
                            SetDeviceState(kDeviceStateIdle);
                        } else {
                            SetDeviceState(kDeviceStateListening);
                        }
                    }
                });
            } else if (strcmp(state->valuestring, "sentence_start") == 0) {
                auto text = cJSON_GetObjectItem(root, "text");
                if (cJSON_IsString(text)) {
                    std::vector<TextGlyph> glyphs;
                    uint8_t bpp = 0;
                    if (!TextGlyphPayload::Parse(root, glyphs, bpp)) {
                        glyphs.clear();
                    }
                    ESP_LOGI(TAG, "<< %s", text->valuestring);
                    Schedule([display, message = std::string(text->valuestring),
                              glyphs = std::move(glyphs), bpp]() {
                        display->AddTextGlyphs(glyphs, bpp);
                        display->SetChatMessage("assistant", message.c_str());
                    });
                }
            }
        } else if (strcmp(type->valuestring, "stt") == 0) {
            auto text = cJSON_GetObjectItem(root, "text");
            if (cJSON_IsString(text)) {
                std::vector<TextGlyph> glyphs;
                uint8_t bpp = 0;
                if (!TextGlyphPayload::Parse(root, glyphs, bpp)) {
                    glyphs.clear();
                }
                ESP_LOGI(TAG, ">> %s", text->valuestring);
                Schedule([display, message = std::string(text->valuestring),
                          glyphs = std::move(glyphs), bpp]() {
                    display->AddTextGlyphs(glyphs, bpp);
                    display->SetChatMessage("user", message.c_str());
                });
            }
        } else if (strcmp(type->valuestring, "llm") == 0) {
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(emotion)) {
                Schedule([display, emotion_str = std::string(emotion->valuestring)]() {
                    display->SetEmotion(emotion_str.c_str());
                });
            }
        } else if (strcmp(type->valuestring, "mcp") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            if (cJSON_IsObject(payload)) {
                McpServer::GetInstance().ParseMessage(payload);
            }
        } else if (strcmp(type->valuestring, "system") == 0) {
            auto command = cJSON_GetObjectItem(root, "command");
            if (cJSON_IsString(command)) {
                ESP_LOGI(TAG, "System command: %s", command->valuestring);
                if (strcmp(command->valuestring, "reboot") == 0) {
                    // Do a reboot if user requests a OTA update
                    Schedule([this]() { Reboot(); });
                } else {
                    ESP_LOGW(TAG, "Unknown system command: %s", command->valuestring);
                }
            }
        } else if (strcmp(type->valuestring, "alert") == 0) {
            auto status = cJSON_GetObjectItem(root, "status");
            auto message = cJSON_GetObjectItem(root, "message");
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(status) && cJSON_IsString(message) && cJSON_IsString(emotion)) {
                Alert(status->valuestring, message->valuestring, emotion->valuestring,
                      Lang::Sounds::OGG_VIBRATION);
            } else {
                ESP_LOGW(TAG, "Alert command requires status, message and emotion");
            }
#if CONFIG_RECEIVE_CUSTOM_MESSAGE
        } else if (strcmp(type->valuestring, "custom") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            ESP_LOGI(TAG, "Received custom message: %s", cJSON_PrintUnformatted(root));
            if (cJSON_IsObject(payload)) {
                Schedule(
                    [this, display, payload_str = std::string(cJSON_PrintUnformatted(payload))]() {
                        display->SetChatMessage("system", payload_str.c_str());
                    });
            } else {
                ESP_LOGW(TAG, "Invalid custom message format: missing payload");
            }
#endif
        } else {
            ESP_LOGW(TAG, "Unknown message type: %s", type->valuestring);
        }
    });

    protocol_->Start();
}

void Application::ShowActivationCode(const std::string& code, const std::string& message) {
    struct digit_sound {
        char digit;
        const std::string_view& sound;
    };
    static const std::array<digit_sound, 10> digit_sounds{
        {digit_sound{'0', Lang::Sounds::OGG_0}, digit_sound{'1', Lang::Sounds::OGG_1},
         digit_sound{'2', Lang::Sounds::OGG_2}, digit_sound{'3', Lang::Sounds::OGG_3},
         digit_sound{'4', Lang::Sounds::OGG_4}, digit_sound{'5', Lang::Sounds::OGG_5},
         digit_sound{'6', Lang::Sounds::OGG_6}, digit_sound{'7', Lang::Sounds::OGG_7},
         digit_sound{'8', Lang::Sounds::OGG_8}, digit_sound{'9', Lang::Sounds::OGG_9}}};

    // This sentence uses 9KB of SRAM, so we need to wait for it to finish
    Alert(Lang::Strings::ACTIVATION, message.c_str(), "link", Lang::Sounds::OGG_ACTIVATION);

    for (const auto& digit : code) {
        auto it = std::find_if(digit_sounds.begin(), digit_sounds.end(),
                               [digit](const digit_sound& ds) { return ds.digit == digit; });
        if (it != digit_sounds.end()) {
            PlaySound(it->sound);
        }
    }
}

void Application::Alert(const char* status, const char* message, const char* emotion,
                        const std::string_view& sound) {
    ESP_LOGW(TAG, "Alert [%s] %s: %s", emotion, status, message);
    auto display = Board::GetInstance().GetDisplay();
    display->SetStatus(status);
    display->SetEmotion(emotion);
    display->SetChatMessage("system", message);
    if (!charging_mode_.load() && !sound.empty()) {
        audio_service_.PlaySound(sound);
    }
}

void Application::DismissAlert() {
    if (GetDeviceState() == kDeviceStateIdle) {
        auto display = Board::GetInstance().GetDisplay();
        display->SetStatus(Lang::Strings::STANDBY);
        display->SetEmotion("neutral");
        display->SetChatMessage("system", "");
    }
}

void Application::ToggleChatState() {
    if (!charging_mode_.load()) xEventGroupSetBits(event_group_, MAIN_EVENT_TOGGLE_CHAT);
}

void Application::StartListening() {
    if (!charging_mode_.load()) xEventGroupSetBits(event_group_, MAIN_EVENT_START_LISTENING);
}

void Application::StopListening() { xEventGroupSetBits(event_group_, MAIN_EVENT_STOP_LISTENING); }

void Application::HandleToggleChatEvent() {
    if (charging_mode_.load()) return;
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    } else if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }

    if (state == kDeviceStateIdle) {
        ListeningMode mode = GetDefaultListeningMode();
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this, mode]() { ContinueOpenAudioChannel(mode); });
            return;
        }
        SetListeningMode(mode);
    } else if (state == kDeviceStateSpeaking) {
        music_playback_ = false;
        music_idle_seconds_ = 0;
        AbortSpeaking(kAbortReasonNone);
    } else if (state == kDeviceStateListening) {
        protocol_->CloseAudioChannel();
    }
}

void Application::ContinueOpenAudioChannel(ListeningMode mode) {
    if (charging_mode_.load())
        return;
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    // Switch to performance mode before connecting to reduce latency
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            // Return to idle so the device is not stuck in the connecting
            // state (not every failure path reports a network error)
            SetDeviceState(kDeviceStateIdle);
            return;
        }
    }

    if (protocol_->TakeServerGreetingPending()) {
        // The server promises an introduction. Wait without capturing speech;
        // the first actual tts:start moves Connecting directly to Speaking.
        listening_mode_ = mode;
        audio_service_.EnableVoiceProcessing(false);
        audio_service_.EnableWakeWordDetection(false);
        return;
    }
    SetListeningMode(mode);
}

void Application::HandleStartListeningEvent() {
    if (charging_mode_.load()) return;
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }

    if (state == kDeviceStateIdle) {
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this]() { ContinueOpenAudioChannel(kListeningModeManualStop); });
            return;
        }
        SetListeningMode(kListeningModeManualStop);
    } else if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
        SetListeningMode(kListeningModeManualStop);
    }
}

void Application::HandleStopListeningEvent() {
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
    } else if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    } else if (state == kDeviceStateListening) {
        if (protocol_) {
            protocol_->SendStopListening();
        }
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::HandleWakeWordDetectedEvent() {
    if (charging_mode_.load()) return;
    if (!protocol_) {
        return;
    }

    auto state = GetDeviceState();
    auto wake_word = audio_service_.GetLastWakeWord();
    ESP_LOGI(TAG, "Wake word detected: %s (state: %d)", wake_word.c_str(), (int)state);

    if (music_playback_) {
        // A song can be stopped only by the board's physical controls. Keep
        // music or room noise from being mistaken for a new wake command.
        audio_service_.EnableWakeWordDetection(false);
        return;
    }

    if (state == kDeviceStateIdle) {
        BeginWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateNotifying) {
        StopNotification();
        BeginWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateSpeaking || state == kDeviceStateListening) {
        AbortSpeaking(kAbortReasonWakeWordDetected);
        // Clear send queue to avoid sending residues to server
        while (audio_service_.PopPacketFromSendQueue())
            ;

        if (state == kDeviceStateListening) {
            protocol_->SendStartListening(GetDefaultListeningMode());
            audio_service_.ResetDecoder();
            audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
            // Re-enable wake word detection as it was stopped by the detection itself
            audio_service_.EnableWakeWordDetection(true);
        } else {
            // Play popup sound and start listening again
            play_popup_on_listening_ = true;
            SetListeningMode(GetDefaultListeningMode());
        }
    } else if (state == kDeviceStateActivating) {
        // Restart the activation check if the wake word is detected during activation
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::BeginWakeWordInvoke(const std::string& wake_word) {
    if (charging_mode_.load())
        return;
    // Must run in the main task with the device in idle state
    audio_service_.EncodeWakeWord();

    // Always pass through the connecting state, even if the audio channel is
    // already opened. ContinueWakeWordInvoke() rejects any other state, so
    // skipping this transition would silently drop the wake word invocation.
    if (!SetDeviceState(kDeviceStateConnecting)) {
        // Wake word detection was stopped by the detection itself; restore it
        // so the device does not become unresponsive to wake words.
        audio_service_.EnableWakeWordDetection(true);
        return;
    }

    if (!protocol_->IsAudioChannelOpened()) {
        // Schedule to let the state change be processed first (UI update),
        // then continue with OpenAudioChannel which may block for ~1 second
        Schedule([this, wake_word]() { ContinueWakeWordInvoke(wake_word); });
        return;
    }
    // Channel already opened, continue directly
    ContinueWakeWordInvoke(wake_word);
}

void Application::ContinueWakeWordInvoke(const std::string& wake_word) {
    if (charging_mode_.load())
        return;
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    // Switch to performance mode before connecting to reduce latency
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            // Return to idle so the device is not stuck in the connecting
            // state (not every failure path reports a network error), and
            // wake word detection is re-enabled by the idle state handler.
            SetDeviceState(kDeviceStateIdle);
            return;
        }
    }

    if (protocol_->TakeServerGreetingPending()) {
        // Do not send the wake-word recording into the fresh introduction.
        while (auto packet = audio_service_.PopWakeWordPacket()) {
        }
        listening_mode_ = GetDefaultListeningMode();
        audio_service_.EnableVoiceProcessing(false);
        audio_service_.EnableWakeWordDetection(false);
        return;
    }

    ESP_LOGI(TAG, "Wake word detected: %s", wake_word.c_str());
#if CONFIG_SEND_WAKE_WORD_DATA
    // Encode and send the wake word data to the server
    while (auto packet = audio_service_.PopWakeWordPacket()) {
        protocol_->SendAudio(std::move(packet));
    }
    // Set the chat state to wake word detected
    protocol_->SendWakeWordDetected(wake_word);
    SetListeningMode(GetDefaultListeningMode());
#else
    // Set flag to play popup sound after state changes to listening
    // (PlaySound here would be cleared by ResetDecoder in EnableVoiceProcessing)
    play_popup_on_listening_ = true;
    SetListeningMode(GetDefaultListeningMode());
#endif
}

void Application::HandleStateChangedEvent() {
    DeviceState new_state = state_machine_.GetState();
    clock_ticks_ = 0;
    // Any state change invalidates a pending deferred listening start;
    // the Listening case below re-arms it when needed.
    pending_listening_start_ = false;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto led = board.GetLed();
    led->OnStateChanged();

    if (charging_mode_.load()) {
        pending_listening_start_ = false;
        audio_service_.EnableVoiceProcessing(false);
        audio_service_.EnableWakeWordDetection(false);
        return;
    }

    switch (new_state) {
        case kDeviceStateUnknown:
        case kDeviceStateIdle:
            display->SetStatus(Lang::Strings::STANDBY);
            display->ClearChatMessages();    // Clear messages first
            display->SetEmotion("neutral");  // Then set emotion (wechat mode checks child count)
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(true);
            music_playback_ = false;
            music_idle_seconds_ = 0;
            music_playback_token_.clear();
            display->HideMusicPlayer();
            break;
        case kDeviceStateConnecting:
            display->SetStatus(Lang::Strings::CONNECTING);
            display->SetEmotion("neutral");
            display->SetChatMessage("system", "");
            break;
        case kDeviceStateListening:
            display->SetStatus(Lang::Strings::LISTENING);
            display->SetEmotion("neutral");

            // Make sure the audio processor is running
            if (play_popup_on_listening_ || !audio_service_.IsAudioProcessorRunning()) {
                // For auto mode, wait for the playback queue to drain before enabling
                // voice processing. This prevents audio truncation when STOP arrives
                // late due to network jitter. Instead of blocking the main loop here,
                // defer the start until MAIN_EVENT_PLAYBACK_DRAINED arrives.
                if (listening_mode_ == kListeningModeAutoStop && !audio_service_.IsPlaybackIdle()) {
                    pending_listening_start_ = true;
                } else {
                    StartListeningAudio();
                }
            } else {
                ConfigureWakeWordForListening();
            }
            break;
        case kDeviceStateSpeaking:
            display->SetStatus(Lang::Strings::SPEAKING);

            if (listening_mode_ != kListeningModeRealtime) {
                audio_service_.EnableVoiceProcessing(false);
                // Only AFE wake word can be detected in speaking mode
                audio_service_.EnableWakeWordDetection(
                    music_playback_ ? false : audio_service_.IsAfeWakeWord());
            }
            audio_service_.ResetDecoder();
            break;
        case kDeviceStateNotifying:
            display->SetStatus(Lang::Strings::SPEAKING);
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
            break;
        case kDeviceStateWifiConfiguring:
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(false);
            break;
        default:
            // Do nothing
            break;
    }
}

void Application::StartListeningAudio() {
    // Runs in the main loop, either directly from HandleStateChangedEvent or
    // deferred via MAIN_EVENT_PLAYBACK_DRAINED once the playback queue drains.
    if (charging_mode_.load() || GetDeviceState() != kDeviceStateListening) {
        return;
    }

    // Send the start listening command
    protocol_->SendStartListening(listening_mode_);
    audio_service_.EnableVoiceProcessing(true);

    ConfigureWakeWordForListening();

    // Play popup sound after ResetDecoder (in EnableVoiceProcessing) has been called
    if (play_popup_on_listening_) {
        play_popup_on_listening_ = false;
        audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
    }
}

void Application::ConfigureWakeWordForListening() {
#ifdef CONFIG_WAKE_WORD_DETECTION_IN_LISTENING
    // Enable wake word detection in listening mode (configured via Kconfig)
    audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
#else
    // Disable wake word detection in listening mode
    audio_service_.EnableWakeWordDetection(false);
#endif
}

void Application::StartNotification(std::string audio_url, std::vector<NotifySubtitle> subtitles) {
    if (charging_mode_.load()) return;
    if (GetDeviceState() != kDeviceStateIdle || notify_player_.IsBusy()) {
        ESP_LOGW(TAG, "Ignoring notify message while device is busy");
        return;
    }

    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    audio_service_.EnableVoiceProcessing(false);
    audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
    audio_service_.ReleaseWakeWordResources();
    while (audio_service_.PopPacketFromSendQueue()) {
        // Discard microphone audio left over from a previous conversation.
    }

    if (!SetDeviceState(kDeviceStateNotifying)) {
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        return;
    }

    audio_service_.ResetDecoder();
    uint32_t playback_id = ++notification_playback_id_;
    if (playback_id == 0) {
        playback_id = ++notification_playback_id_;
    }
    audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);

    bool started = notify_player_.Start(
        std::move(audio_url), std::move(subtitles), playback_id,
        [this](uint32_t id, const std::string& text) {
            Schedule([this, id, text]() {
                if (GetDeviceState() == kDeviceStateNotifying && notification_playback_id_ == id) {
                    Board::GetInstance().GetDisplay()->SetChatMessage("assistant", text.c_str());
                }
            });
        },
        [this](uint32_t id, bool success) {
            Schedule([this, id, success]() { HandleNotificationFinished(id, success); });
        });

    if (!started) {
        ESP_LOGE(TAG, "Failed to start notification playback");
        StopNotification();
    }
}

void Application::StopNotification() {
    notify_player_.Stop();
    audio_service_.ResetDecoder();
    auto& board = Board::GetInstance();
    board.GetDisplay()->SetChatMessage("assistant", "");
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
    if (GetDeviceState() == kDeviceStateNotifying) {
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::HandleNotificationFinished(uint32_t playback_id, bool success) {
    if (GetDeviceState() != kDeviceStateNotifying || notification_playback_id_ != playback_id) {
        return;
    }
    ESP_LOGI(TAG, "Notification playback %lu %s", static_cast<unsigned long>(playback_id),
             success ? "completed" : "failed");
    StopNotification();
}

void Application::Schedule(std::function<void()>&& callback) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        main_tasks_.push_back(std::move(callback));
    }
    xEventGroupSetBits(event_group_, MAIN_EVENT_SCHEDULE);
}

void Application::AbortSpeaking(AbortReason reason) {
    ESP_LOGI(TAG, "Abort speaking");
    aborted_ = true;
    music_playback_ = false;
    music_idle_seconds_ = 0;
    music_playback_token_.clear();
    Board::GetInstance().GetDisplay()->HideMusicPlayer();
    if (protocol_) {
        protocol_->SendAbortSpeaking(reason);
    }
}

void Application::SetListeningMode(ListeningMode mode) {
    listening_mode_ = mode;
    SetDeviceState(kDeviceStateListening);
}

ListeningMode Application::GetDefaultListeningMode() const {
    return aec_mode_ == kAecOff ? kListeningModeAutoStop : kListeningModeRealtime;
}

void Application::Reboot() {
    ESP_LOGI(TAG, "Rebooting...");
    if (GetDeviceState() == kDeviceStateNotifying) {
        StopNotification();
    }
    // Disconnect the audio channel
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        protocol_->CloseAudioChannel();
    }
    protocol_.reset();
    audio_service_.Stop();

    vTaskDelay(pdMS_TO_TICKS(1000));
    esp_restart();
}

bool Application::UpgradeFirmware(const std::string& url, const std::string& version) {
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();

    std::string upgrade_url = url;
    std::string version_info = version.empty() ? "(Manual upgrade)" : version;

    if (GetDeviceState() == kDeviceStateNotifying) {
        StopNotification();
    }

    // Close audio channel if it's open
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        ESP_LOGI(TAG, "Closing audio channel before firmware upgrade");
        protocol_->CloseAudioChannel();
    }
    ESP_LOGI(TAG, "Starting firmware upgrade from URL: %s", upgrade_url.c_str());

    Alert(Lang::Strings::OTA_UPGRADE, Lang::Strings::UPGRADING, "download",
          Lang::Sounds::OGG_UPGRADE);
    vTaskDelay(pdMS_TO_TICKS(3000));

    SetDeviceState(kDeviceStateUpgrading);

    std::string message = std::string(Lang::Strings::NEW_VERSION) + version_info;
    display->SetChatMessage("system", message.c_str());

    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    audio_service_.Stop();
    vTaskDelay(pdMS_TO_TICKS(1000));

    bool upgrade_success = Ota::Upgrade(upgrade_url, [this, display](int progress, size_t speed) {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
        Schedule([display, message = std::string(buffer)]() {
            display->SetChatMessage("system", message.c_str());
        });
    });

    if (!upgrade_success) {
        // Upgrade failed, restart audio service and continue running
        ESP_LOGE(TAG,
                 "Firmware upgrade failed, restarting audio service and continuing operation...");
        audio_service_.Start();                              // Restart audio service
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);  // Restore power save level
        Alert(Lang::Strings::ERROR, Lang::Strings::UPGRADE_FAILED, "cancel",
              Lang::Sounds::OGG_EXCLAMATION);
        vTaskDelay(pdMS_TO_TICKS(3000));
        return false;
    } else {
        // Upgrade success, reboot immediately
        ESP_LOGI(TAG, "Firmware upgrade successful, rebooting...");
        display->SetChatMessage("system", "Upgrade successful, rebooting...");
        vTaskDelay(pdMS_TO_TICKS(1000));  // Brief pause to show message
        Reboot();
        return true;
    }
}

void Application::WakeWordInvoke(const std::string& wake_word) {
    if (charging_mode_.load())
        return;
    if (!protocol_) {
        return;
    }

    auto state = GetDeviceState();

    if (state == kDeviceStateIdle) {
        // May be called from outside the main task (e.g. board button
        // callbacks), so schedule the invocation instead of running it here
        Schedule([this, wake_word]() {
            if (charging_mode_.load())
                return;
            if (GetDeviceState() == kDeviceStateIdle) {
                BeginWakeWordInvoke(wake_word);
            }
        });
    } else if (state == kDeviceStateNotifying) {
        Schedule([this, wake_word]() {
            if (charging_mode_.load())
                return;
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
                BeginWakeWordInvoke(wake_word);
            }
        });
    } else if (state == kDeviceStateSpeaking) {
        Schedule([this]() { AbortSpeaking(kAbortReasonNone); });
    } else if (state == kDeviceStateListening) {
        Schedule([this]() {
            if (protocol_) {
                protocol_->CloseAudioChannel();
            }
        });
    }
}

bool Application::CanEnterSleepMode() {
    if (GetDeviceState() != kDeviceStateIdle) {
        return false;
    }

    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        return false;
    }

    if (!audio_service_.IsIdle()) {
        return false;
    }

    // Now it is safe to enter sleep mode
    return true;
}

void Application::RegisterMcpBroadcastCallback(std::function<void(const std::string&)> callback) {
    mcp_broadcast_callback_ = std::move(callback);
}

void Application::SendMcpMessage(const std::string& payload) {
    // Always schedule to run in main task for thread safety
    Schedule([this, payload]() {
        if (protocol_) {
            protocol_->SendMcpMessage(payload);
        }
        if (mcp_broadcast_callback_) {
            mcp_broadcast_callback_(payload);
        }
    });
}

void Application::SetAecMode(AecMode mode) {
    aec_mode_ = mode;
    Schedule([this]() {
        auto& board = Board::GetInstance();
        auto display = board.GetDisplay();
        switch (aec_mode_) {
            case kAecOff:
                audio_service_.EnableDeviceAec(false);
                display->ShowNotification(Lang::Strings::RTC_MODE_OFF);
                break;
            case kAecOnServerSide:
                audio_service_.EnableDeviceAec(false);
                display->ShowNotification(Lang::Strings::RTC_MODE_ON);
                break;
            case kAecOnDeviceSide:
                audio_service_.EnableDeviceAec(true);
                display->ShowNotification(Lang::Strings::RTC_MODE_ON);
                break;
        }

        // If the AEC mode is changed, close the audio channel
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
    });
}

void Application::PlaySound(const std::string_view& sound) {
    if (!charging_mode_.load()) audio_service_.PlaySound(sound);
}

void Application::ResetProtocol() {
    Schedule([this]() {
        if (GetDeviceState() == kDeviceStateNotifying) {
            StopNotification();
        }
        // Close audio channel if opened
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
        // Reset protocol
        protocol_.reset();
    });
}
